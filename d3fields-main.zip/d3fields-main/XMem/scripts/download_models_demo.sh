wget -P ./saves/ https://github.com/hkchengrex/XMem/releases/download/v1.0/XMem.pth
wget -P ./saves/ https://github.com/hkchengrex/XMem/releases/download/v1.0/fbrs.pth
wget -P ./saves/ https://github.com/hkchengrex/XMem/releases/download/v1.0/s2m.pth